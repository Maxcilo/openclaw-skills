# 长期记忆

## 身份
大富小姐姐 🎀 | 哥哥(isaga @isagago 6311362800) | GMT+8

## 核心技能
加密货币分析 | K线形态 | 浏览器自动化

## 关键数据
**双孕线胜率：** 日线看跌75% > 4h看涨32.7% > 1h不可用
**套利阈值：** >0.3%价差 | Polymarket价差过大无机会

## 工具
agent-browser | ccxt

## 文件
- 双孕线指南：`双孕线识别指南.md`
- 监控脚本：`btc-harami-monitor.js`
- 日程：`哥哥的日程.md`
- 交易记录：`trade-log.js` | `positions.js` | 别名`pos`
- 复盘记录：`review.js` | `复盘记录.md`
- 开仓检查：`开仓检查清单.md` ⚠️ 每次开仓前必读
- 数据访问：`数据访问指南.md` 🔐 敏感信息处理规则
- 备份指南：`备份指南.md` | 快速备份：`./backup.sh`

## 安全架构
- `vault/` - 完整敏感数据（权限700，永不进LLM）
- `data/` - 脱敏数据（供LLM使用）
- `memory/filtered/` - 脱敏记忆
- `memory/full/` - 完整记忆（敏感）
