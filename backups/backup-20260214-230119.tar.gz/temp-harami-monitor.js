#!/usr/bin/env node
/**
 * BTC & ETH 临时监控 - 30分钟和1小时双孕线
 * 3小时后自动删除
 */

const ccxt = require('ccxt');
const { execSync } = require('child_process');

// 计算K线实体
function getBody(candle) {
    return {
        top: Math.max(candle.open, candle.close),
        bottom: Math.min(candle.open, candle.close),
        size: Math.abs(candle.close - candle.open),
        isGreen: candle.close > candle.open
    };
}

// 检查趋势
function checkTrend(data, index, lookback = 5) {
    if (index < lookback) return 'neutral';
    const recentCandles = data.slice(index - lookback, index);
    let upCount = 0, downCount = 0;
    
    for (let i = 1; i < recentCandles.length; i++) {
        if (recentCandles[i].close > recentCandles[i-1].close) upCount++;
        if (recentCandles[i].close < recentCandles[i-1].close) downCount++;
    }
    
    if (upCount >= lookback * 0.6) return 'uptrend';
    if (downCount >= lookback * 0.6) return 'downtrend';
    return 'neutral';
}

// 检查双孕线
function isDoubleHarami(data, index, minBodySize) {
    if (index < 2) return false;
    
    const k1 = data[index - 2];
    const k2 = data[index - 1];
    const k3 = data[index];
    
    const b1 = getBody(k1);
    const b2 = getBody(k2);
    const b3 = getBody(k3);
    
    const k2Inside = b2.top <= b1.top && b2.bottom >= b1.bottom;
    const k3Inside = b3.top <= b1.top && b3.bottom >= b1.bottom;
    
    if (!k2Inside || !k3Inside) return false;
    
    const k2Small = b2.size < b1.size * 0.5;
    const k3Small = b3.size < b1.size * 0.5;
    
    if (!k2Small || !k3Small) return false;
    
    const trend = checkTrend(data, index - 2, 5);
    
    if (b1.size >= minBodySize * 2) return true;
    
    if (b1.size >= minBodySize) {
        if (trend === 'uptrend' && b1.isGreen) return true;
        if (trend === 'downtrend' && !b1.isGreen) return true;
    }
    
    return false;
}

// 格式化价格（带千位分隔符）
function formatPrice(price) {
    // 根据价格大小决定小数位数
    if (price >= 1000) {
        return price.toLocaleString('en-US', { 
            minimumFractionDigits: 2, 
            maximumFractionDigits: 2 
        });
    } else if (price >= 1) {
        return price.toLocaleString('en-US', { 
            minimumFractionDigits: 2, 
            maximumFractionDigits: 4 
        });
    } else {
        return price.toLocaleString('en-US', { 
            minimumFractionDigits: 4, 
            maximumFractionDigits: 8 
        });
    }
}

// 格式化时间为北京时间
function formatTimestamp(timestamp, timeframe) {
    const date = new Date(timestamp + 8 * 60 * 60 * 1000);
    if (timeframe === '30m' || timeframe === '1h') {
        return date.toISOString().slice(0, 16).replace('T', ' ');
    }
    return date.toISOString().replace('T', ' ').slice(0, 16);
}

// 发送通知
function sendNotification(message) {
    try {
        const cmd = `/root/.nvm/versions/node/v22.22.0/bin/openclaw message send --channel telegram --target 6311362800 --message ${JSON.stringify(message)}`;
        execSync(cmd, { stdio: 'inherit' });
        console.log('✓ 通知已发送');
    } catch (err) {
        console.error('发送通知失败:', err.message);
    }
}

// 检查单个币种和周期
async function checkPair(exchange, symbol, timeframe, minBodySize) {
    const ohlcv = await exchange.fetchOHLCV(symbol, timeframe, undefined, 100);
    
    const data = ohlcv.map(candle => ({
        timestamp: candle[0],
        open: candle[1],
        high: candle[2],
        low: candle[3],
        close: candle[4],
        volume: candle[5]
    }));
    
    if (data.length < 10) return null;
    
    const index = data.length - 1;
    
    if (isDoubleHarami(data, index, minBodySize)) {
        const k1 = data[index - 2];
        const k2 = data[index - 1];
        const k3 = data[index];
        
        const b1 = getBody(k1);
        const b2 = getBody(k2);
        const b3 = getBody(k3);
        
        const trend = checkTrend(data, index - 2, 5);
        const trendText = trend === 'uptrend' ? '(前期上涨)' : trend === 'downtrend' ? '(前期下跌)' : '';
        
        return {
            symbol,
            timeframe,
            type: b1.isGreen ? '看跌双孕线' : '看涨双孕线',
            signal: b1.isGreen ? '⬇️ 可能见顶回落' : '⬆️ 可能见底反转',
            trend: trendText,
            k1: {
                time: formatTimestamp(k1.timestamp, timeframe),
                open: k1.open,
                close: k1.close,
                body: b1.size.toFixed(2),
                color: b1.isGreen ? '阳线' : '阴线'
            },
            k2: {
                time: formatTimestamp(k2.timestamp, timeframe),
                open: k2.open,
                close: k2.close,
                body: b2.size.toFixed(2),
                color: b2.isGreen ? '阳线' : '阴线'
            },
            k3: {
                time: formatTimestamp(k3.timestamp, timeframe),
                open: k3.open,
                close: k3.close,
                body: b3.size.toFixed(2),
                color: b3.isGreen ? '阳线' : '阴线'
            }
        };
    }
    
    return null;
}

// 主监控函数
async function monitor() {
    const now = new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString().replace('T', ' ').slice(0, 19);
    console.log(`[${now} 北京时间] 临时监控检查...`);
    
    try {
        const exchange = new ccxt.binance();
        
        const pairs = [
            { symbol: 'BTC/USDT', tf: '30m', minBody: 30, name: 'BTC 30分钟' },
            { symbol: 'BTC/USDT', tf: '1h', minBody: 50, name: 'BTC 1小时' },
            { symbol: 'ETH/USDT', tf: '30m', minBody: 2, name: 'ETH 30分钟' },
            { symbol: 'ETH/USDT', tf: '1h', minBody: 3, name: 'ETH 1小时' }
        ];
        
        let foundAny = false;
        
        for (const { symbol, tf, minBody, name } of pairs) {
            console.log(`检查 ${name}...`);
            
            const harami = await checkPair(exchange, symbol, tf, minBody);
            
            if (harami) {
                const message = `🎀 临时监控提醒

💰 币种：${name}
📊 类型：${harami.type} ${harami.trend}
📅 时间：${harami.k1.time} ~ ${harami.k3.time}
💵 当前价格：$${formatPrice(harami.k3.close)}

K1 (母线): ${harami.k1.color}
  开盘: $${formatPrice(harami.k1.open)}
  收盘: $${formatPrice(harami.k1.close)}
  实体: ${harami.k1.body}

K2 (孕线1): ${harami.k2.color}
  开盘: $${formatPrice(harami.k2.open)}
  收盘: $${formatPrice(harami.k2.close)}
  实体: ${harami.k2.body}

K3 (孕线2): ${harami.k3.color}
  开盘: $${formatPrice(harami.k3.open)}
  收盘: $${formatPrice(harami.k3.close)}
  实体: ${harami.k3.body}

${harami.signal}`;
                
                console.log('\n' + '='.repeat(60));
                console.log(message);
                console.log('='.repeat(60) + '\n');
                
                sendNotification(message);
                foundAny = true;
            }
        }
        
        if (!foundAny) {
            console.log('未发现双孕线形态');
        }
        
    } catch (error) {
        console.error('监控出错:', error.message);
    }
}

monitor().then(() => {
    console.log('检查完成');
    process.exit(0);
}).catch(err => {
    console.error('执行失败:', err);
    process.exit(1);
});
